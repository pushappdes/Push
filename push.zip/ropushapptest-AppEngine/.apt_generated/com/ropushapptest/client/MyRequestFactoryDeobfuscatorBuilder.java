// Automatically Generated -- DO NOT EDIT
// com.ropushapptest.client.MyRequestFactory
package com.ropushapptest.client;
import java.util.Arrays;
import com.google.web.bindery.requestfactory.vm.impl.OperationData;
import com.google.web.bindery.requestfactory.vm.impl.OperationKey;
public final class MyRequestFactoryDeobfuscatorBuilder extends com.google.web.bindery.requestfactory.vm.impl.Deobfuscator.Builder {
{
withOperation(new OperationKey("2jiSfevH26lIxJ9qZPX8z5Q4Z0U="),
  new OperationData.Builder()
  .withClientMethodDescriptor("()Lcom/google/web/bindery/requestfactory/shared/InstanceRequest;")
  .withDomainMethodDescriptor("()Ljava/lang/String;")
  .withMethodName("send")
  .withRequestContext("com.ropushapptest.client.MyRequestFactory$MessageRequest")
  .build());
withOperation(new OperationKey("S18sdWlDHmNZLdXifIG$h0dv3UM="),
  new OperationData.Builder()
  .withClientMethodDescriptor("()Lcom/google/web/bindery/requestfactory/shared/Request;")
  .withDomainMethodDescriptor("()Ljava/lang/String;")
  .withMethodName("getMessage")
  .withRequestContext("com.ropushapptest.client.MyRequestFactory$HelloWorldRequest")
  .build());
withOperation(new OperationKey("$jagET6Eam_A6UJJYf0dNJMyMko="),
  new OperationData.Builder()
  .withClientMethodDescriptor("()Lcom/google/web/bindery/requestfactory/shared/InstanceRequest;")
  .withDomainMethodDescriptor("()V")
  .withMethodName("register")
  .withRequestContext("com.ropushapptest.client.MyRequestFactory$RegistrationInfoRequest")
  .build());
withOperation(new OperationKey("qyzXSHVo6J8VE__ht6jeLA6FzgQ="),
  new OperationData.Builder()
  .withClientMethodDescriptor("()Lcom/google/web/bindery/requestfactory/shared/InstanceRequest;")
  .withDomainMethodDescriptor("()V")
  .withMethodName("unregister")
  .withRequestContext("com.ropushapptest.client.MyRequestFactory$RegistrationInfoRequest")
  .build());
withRawTypeToken("8KVVbwaaAtl6KgQNlOTsLCp9TIU=", "com.google.web.bindery.requestfactory.shared.ValueProxy");
withRawTypeToken("FXHD5YU0TiUl3uBaepdkYaowx9k=", "com.google.web.bindery.requestfactory.shared.BaseProxy");
withRawTypeToken("TU6dOqHFQJ3VRTpHDnCwh84oi6c=", "com.ropushapptest.shared.MessageProxy");
withRawTypeToken("ORIqdVqVQMyWoGXp6JXhbw$WR3k=", "com.ropushapptest.shared.RegistrationInfoProxy");
withClientToDomainMappings("com.ropushapptest.server.Message", Arrays.asList("com.ropushapptest.shared.MessageProxy"));
withClientToDomainMappings("com.ropushapptest.server.RegistrationInfo", Arrays.asList("com.ropushapptest.shared.RegistrationInfoProxy"));
}}
